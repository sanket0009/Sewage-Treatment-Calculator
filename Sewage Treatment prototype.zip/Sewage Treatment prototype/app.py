import functools
import json
import math
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, cast

from flask import Flask, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE_PATH = BASE_DIR / "calculations.db"

SECTION_ONE_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Design Discharge (q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Provide the design discharge in megalitres per day.",
    },
    {
        "name": "opening_o",
        "label": "Opening Size (O)",
        "suffix": "mm",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Clear spacing between bars (12 mm - 40 mm).",
    },
    {
        "name": "bar_size_b",
        "label": "Bar Size (b)",
        "suffix": "mm",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Thickness of each bar (8 mm - 15 mm).",
    },
    {
        "name": "angle_phi",
        "label": "Angle of Inclination (phi)",
        "suffix": "deg",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "max": "90",
        "cast": "float",
        "min_value": 0.0,
        "help": "Inclination of the screen (45 deg - 60 deg typical).",
    },
    {
        "name": "velocity_vs",
        "label": "Velocity Through Screen (Vs)",
        "suffix": "m/s",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Provide velocity through the screen (0.8 - 1.2 m/s).",
    },
    {
        "name": "depth_h",
        "label": "Depth of Water (h)",
        "suffix": "m",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Depth of water across the screen (1.0 - 2.5 m).",
    },
    {
        "name": "screen_type",
        "label": "Type of Screen",
        "type": "text",
        "cast": "str",
        "placeholder": "Medium Bar Screen",
        "help": "Optional descriptor for record keeping.",
        "required": False,
    },
]

SECTION_TWO_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Design Discharge (q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Provide the design discharge in megalitres per day.",
    },
    {
        "name": "specific_gravity_g",
        "label": "Specific Gravity (G)",
        "suffix": "",
        "type": "number",
        "step": "0.01",
        "min": "1",
        "cast": "float",
        "min_value": 1.0,
        "help": "Specific gravity of grit particles (typically 2.65 for sand).",
    },
    {
        "name": "temperature_t",
        "label": "Temperature (T)",
        "suffix": "°C",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Wastewater temperature in degrees Celsius.",
    },
    {
        "name": "horizontal_velocity_vh",
        "label": "Horizontal Velocity (Vh)",
        "suffix": "m/s",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Design horizontal flow velocity (0.15 - 0.3 m/s typical).",
    },
    {
        "name": "width_b",
        "label": "Width (B)",
        "suffix": "m",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Width of the grit chamber in metres.",
    },
    {
        "name": "particle_size_d",
        "label": "Particle Size (d)",
        "suffix": "mm",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Minimum particle diameter to be removed (typically 0.2 mm).",
    },
]

SECTION_THREE_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Design Discharge (q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Provide the design discharge in megalitres per day.",
    },
    {
        "name": "detention_time_db",
        "label": "Detention Time (Db)",
        "suffix": "hrs",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Design detention time (typical range: 2–4 hrs).",
    },
    {
        "name": "specific_gravity_g",
        "label": "Specific Gravity (G)",
        "suffix": "",
        "type": "number",
        "step": "0.01",
        "min": "1",
        "cast": "float",
        "min_value": 1.0,
        "help": "Specific gravity of organic solids (typically 1.4).",
    },
    {
        "name": "particle_size_d",
        "label": "Particle Size (d)",
        "suffix": "mm",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Minimum particle diameter to be removed (e.g. 0.6 mm).",
    },
    {
        "name": "temperature_t",
        "label": "Temperature (T)",
        "suffix": "°C",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Average wastewater temperature.",
    },
    {
        "name": "viscosity_mu",
        "label": "Viscosity (υ)",
        "suffix": "×10⁻³ NS/m²",
        "type": "number",
        "step": "0.001",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Dynamic viscosity (e.g. 1.0 for 1.0×10⁻³ NS/m² at 20°C).",
    },
    {
        "name": "side_water_depth_h",
        "label": "Side Water Depth (H)",
        "suffix": "m",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Side water depth of the tank (typical range: 2.5–4 m).",
    },
    {
        "name": "lb_ratio",
        "label": "L:B Ratio",
        "suffix": "",
        "type": "number",
        "step": "0.1",
        "min": "1",
        "max": "3",
        "cast": "float",
        "min_value": 1.0,
        "help": "Length-to-breadth ratio for rectangular tank (range: 1–3).",
    },
]

SECTION_FOUR_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Average Daily Flow (Q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Average daily discharge in megalitres per day (typical: 40–60 MLD).",
    },
    {
        "name": "inlet_bod_s0",
        "label": "Inlet BOD (S₀)",
        "suffix": "mg/L",
        "type": "number",
        "step": "1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Influent BOD concentration (typical: 200–350 mg/L).",
    },
    {
        "name": "outlet_bod_s1",
        "label": "Outlet BOD (S₁)",
        "suffix": "mg/L",
        "type": "number",
        "step": "1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Desired effluent BOD concentration (e.g. 20–30 mg/L for conventional ASP).",
    },
    {
        "name": "mlss_xt",
        "label": "MLSS (Xₜ)",
        "suffix": "mg/L",
        "type": "number",
        "step": "100",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Mixed Liquor Suspended Solids concentration (typical: 2000–4000 mg/L).",
    },
    {
        "name": "hrt",
        "label": "HRT",
        "suffix": "hrs",
        "type": "number",
        "step": "0.5",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Hydraulic Retention Time (conventional ASP: 6–8 hrs; extended aeration: 16–24 hrs).",
    },
    {
        "name": "depth_h",
        "label": "Tank Depth (H)",
        "suffix": "m",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Design depth of the aeration tank (typical: 3–5 m).",
    },
    {
        "name": "lb_ratio",
        "label": "L:B Ratio",
        "suffix": "",
        "type": "number",
        "step": "0.1",
        "min": "1",
        "cast": "float",
        "min_value": 1.0,
        "help": "Length-to-breadth ratio of the aeration tank (typical: 1–5).",
    },
]

SECTION_FIVE_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Flow Rate (Q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Average daily flow rate in megalitres per day.",
    },
    {
        "name": "detention_time_dt",
        "label": "Detention Time (DT)",
        "suffix": "hrs",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Hydraulic detention time in hours (typical: 1.5–3 hrs).",
    },
    {
        "name": "depth_d",
        "label": "Depth of Tank (d)",
        "suffix": "m",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Side water depth of the clarifier (typical: 3–5 m).",
    },
]

SECTION_SIX_FIELDS: List[Dict[str, object]] = [
    {
        "name": "design_discharge_q",
        "label": "Discharge (Q)",
        "suffix": "MLD",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Average daily flow rate in megalitres per day.",
    },
    {
        "name": "influent_bod_li",
        "label": "Influent BOD (Lᵢ)",
        "suffix": "mg/L",
        "type": "number",
        "step": "1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Incoming BOD concentration (typical: 150–300 mg/L).",
    },
    {
        "name": "effluent_bod_le",
        "label": "Effluent BOD (Lₑ)",
        "suffix": "mg/L",
        "type": "number",
        "step": "1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Required outlet BOD (e.g. 30 mg/L).",
    },
    {
        "name": "temperature_t",
        "label": "Temperature (T)",
        "suffix": "°C",
        "type": "number",
        "step": "0.5",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Average wastewater temperature (typical: 25–30 °C).",
    },
    {
        "name": "k20",
        "label": "K₂₀ (rate at 20 °C)",
        "suffix": "/day",
        "type": "number",
        "step": "0.01",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "BOD removal rate constant at 20 °C (typical facultative pond: 0.1–0.3).",
    },
    {
        "name": "depth_d",
        "label": "Pond Depth (d)",
        "suffix": "m",
        "type": "number",
        "step": "0.1",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Effective depth of the oxidation pond (typical: 0.4–1.5 m).",
    },
    {
        "name": "lb_ratio",
        "label": "L:B Ratio",
        "suffix": "",
        "type": "number",
        "step": "0.5",
        "min": "1",
        "cast": "float",
        "min_value": 1.0,
        "help": "Length-to-breadth ratio of each pond (typical: 2–4; use 3 for standard design).",
    },
    {
        "name": "max_pond_area_ha",
        "label": "Max Area / Pond",
        "suffix": "ha",
        "type": "number",
        "step": "0.5",
        "min": "0",
        "cast": "float",
        "min_value": 0.0,
        "help": "Maximum allowable surface area per individual pond (typical: 10–20 ha).",
    },
]

SECTIONS: List[Dict[str, object]] = [
    {
        "id": "section-1",
        "title": "Section 1 - Bar Screen",
        "description": (
            "Calculate the governing variables for a medium bar screen using discharge, opening size, bar thickness, "
            "inclination, velocity through the screen, and water depth. Results are projected onto a static reference diagram."
        ),
        "diagram": "bar-screen",
        "fields": SECTION_ONE_FIELDS,
    },
    {
        "id": "section-2",
        "title": "Section 2 - Grit Chamber",
        "description": (
            "Calculate the design dimensions of a grit chamber using discharge, specific gravity, temperature, "
            "horizontal velocity, chamber width, and particle size. Outputs length, height, and detention time."
        ),
        "diagram": "grit-chamber",
        "fields": SECTION_TWO_FIELDS,
    },
    {
        "id": "section-3",
        "title": "Section 3 - Primary Sedimentation Tank",
        "description": (
            "Calculate the design dimensions of a primary sedimentation tank using discharge, detention time, "
            "specific gravity, particle size, temperature, viscosity, side water depth, and L:B ratio. "
            "Outputs volume, surface area, length, breadth, and equivalent circular diameter."
        ),
        "diagram": "primary-sedimentation",
        "fields": SECTION_THREE_FIELDS,
    },
    {
        "id": "section-4",
        "title": "Section 4 - Activated Sludge Process",
        "description": (
            "Calculate the design dimensions of an aeration tank using average daily flow, inlet/outlet BOD, "
            "MLSS, HRT, tank depth, and L:B ratio. Outputs tank volume, dimensions, F/M ratio, and BOD removal efficiency."
        ),
        "diagram": "activated-sludge",
        "fields": SECTION_FOUR_FIELDS,
    },
    {
        "id": "section-5",
        "title": "Section 5 - Secondary Clarifier",
        "description": (
            "Calculate the design dimensions of a secondary clarifier (effluent clarifier) using flow rate, "
            "detention time, and tank depth. Outputs volume, surface area, diameter, and surface overflow rate "
            "with an automatic SOR design check (acceptable range: 20–40 m³/m²/day)."
        ),
        "diagram": "secondary-clarifier",
        "fields": SECTION_FIVE_FIELDS,
    },
    {
        "id": "section-6",
        "title": "Section 6 - Oxidation Pond",
        "description": (
            "Calculate the design dimensions of an oxidation pond using discharge, influent/effluent BOD, "
            "temperature, rate constant, depth, and L:B ratio. "
            "Outputs KT, detention time, volume, surface area, pond dimensions, and number of ponds required."
        ),
        "diagram": "oxidation-pond",
        "fields": SECTION_SIX_FIELDS,
    },
]

app = Flask(__name__)
app.secret_key = "sewage-treatment-dev-secret-key-change-in-production"


def init_db() -> None:
    """Create tables needed to persist section results."""
    with sqlite3.connect(DATABASE_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS section_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                section_id TEXT NOT NULL,
                inputs_json TEXT NOT NULL,
                metrics_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_section_results_section
                ON section_results (section_id, id DESC)
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )


def login_required(view):
    """Redirect to login if the user is not authenticated."""
    @functools.wraps(view)
    def wrapped(**kwargs):
        if session.get("user_id") is None:
            return redirect(url_for("login"))
        return view(**kwargs)
    return wrapped


def get_db() -> sqlite3.Connection:
    """Return a request-scoped SQLite connection."""
    if "db_conn" not in g:
        g.db_conn = sqlite3.connect(DATABASE_PATH)
        g.db_conn.row_factory = sqlite3.Row
    return g.db_conn


@app.teardown_appcontext
def close_db(exc: Optional[BaseException]) -> None:
    """Close the SQLite connection at the end of a request."""
    conn = g.pop("db_conn", None)
    if conn is not None:
        conn.close()


def persist_section_result(section_id: str, inputs: Dict[str, float], metrics: Dict[str, float]) -> None:
    """Insert a calculation record for a given section."""
    conn = get_db()
    conn.execute(
        """
        INSERT INTO section_results (
            section_id, inputs_json, metrics_json, created_at
        ) VALUES (?, ?, ?, ?)
        """,
        (
            section_id,
            json.dumps(inputs),
            json.dumps(metrics),
            datetime.utcnow().isoformat(timespec="seconds"),
        ),
    )
    conn.commit()


def fetch_latest_section_results() -> Dict[str, Dict[str, object]]:
    """Return the most recently stored calculation per section."""
    conn = get_db()
    cursor = conn.execute(
        """
        SELECT
            section_id,
            inputs_json,
            metrics_json,
            created_at
        FROM section_results
        ORDER BY section_id, id DESC
        """
    )
    results: Dict[str, Dict[str, object]] = {}
    for row in cursor.fetchall():
        section_id = row["section_id"]
        if section_id in results:
            continue
        results[section_id] = {
            "inputs": json.loads(row["inputs_json"]),
            "metrics": json.loads(row["metrics_json"]),
            "created_at": row["created_at"],
        }
    return results


def compute_section_one_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the medium bar screen."""
    q_mld = inputs["design_discharge_q"]
    opening_mm = inputs["opening_o"]
    bar_mm = inputs["bar_size_b"]
    angle_deg = inputs["angle_phi"]
    velocity_vs = inputs["velocity_vs"]
    depth_h = inputs["depth_h"]

    opening_m = opening_mm / 1000.0
    bar_m = bar_mm / 1000.0
    sin_phi = math.sin(math.radians(angle_deg)) if angle_deg else 0.0

    q_cumecs = q_mld * 1_000_000.0 / (24.0 * 60.0 * 60.0)
    net_area_an = q_cumecs / velocity_vs if velocity_vs else 0.0
    gross_area_ag = (
        net_area_an * (opening_m + bar_m) / opening_m if opening_m else 0.0
    )
    gross_inclined_area_agi = gross_area_ag / sin_phi if sin_phi else 0.0

    length_l = depth_h
    total_opening_width_wo = net_area_an / length_l if length_l else 0.0
    raw_opening_count = total_opening_width_wo / opening_m if opening_m else 0.0
    openings_count = max(1, round(raw_opening_count))
    bars_count = max(0, openings_count - 1)
    screen_width_w = opening_m * openings_count + bar_m * bars_count

    approach_velocity_v = (
        velocity_vs * (opening_m / (opening_m + bar_m))
        if (opening_m + bar_m)
        else 0.0
    )
    head_loss_hl = 0.0729 * (approach_velocity_v**2 - velocity_vs**2)

    return {
        "design_discharge_q": q_mld,
        "discharge_q_cumecs": q_cumecs,
        "opening_mm": opening_mm,
        "opening_m": opening_m,
        "bar_mm": bar_mm,
        "bar_m": bar_m,
        "angle_deg": angle_deg,
        "velocity_vs": velocity_vs,
        "approach_velocity_v": approach_velocity_v,
        "head_loss_hl": head_loss_hl,
        "net_area_an": net_area_an,
        "gross_area_ag": gross_area_ag,
        "gross_inclined_area_agi": gross_inclined_area_agi,
        "length_l": length_l,
        "total_opening_width_wo": total_opening_width_wo,
        "raw_openings": raw_opening_count,
        "openings_count": openings_count,
        "bars_count": bars_count,
        "screen_width_w": screen_width_w,
    }


def compute_section_two_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the grit chamber."""
    q_mld = inputs["design_discharge_q"]
    G = inputs["specific_gravity_g"]
    T = inputs["temperature_t"]
    Vh = inputs["horizontal_velocity_vh"]
    B = inputs["width_b"]
    d_mm = inputs["particle_size_d"]

    # Q = (q × 10³) / (24 × 60 × 60)  →  m³/s
    Q = (q_mld * 1_000.0) / (24.0 * 60.0 * 60.0)

    # Vs = 60.6 × d × (G − 1) × (3T + 70) / 100  →  result in mm/s; convert to m/s
    Vs_mm_s = 60.6 * d_mm * (G - 1.0) * (3.0 * T + 70.0) / 100.0
    Vs = Vs_mm_s / 1_000.0  # m/s

    # C/S Area = Q / Vh
    cross_section_area = Q / Vh if Vh else 0.0

    # H = C/S Area / B
    H = cross_section_area / B if B else 0.0

    # Dt = H / Vs
    Dt = H / Vs if Vs else 0.0

    # L = Vh × Dt
    L = Vh * Dt

    return {
        "design_discharge_q": q_mld,
        "discharge_Q": Q,
        "specific_gravity_g": G,
        "temperature_t": T,
        "horizontal_velocity_vh": Vh,
        "width_b": B,
        "particle_size_d": d_mm,
        "settling_velocity_vs_mm_s": Vs_mm_s,
        "settling_velocity_vs": Vs,
        "cross_section_area": cross_section_area,
        "height_h": H,
        "detention_time_dt": Dt,
        "length_l": L,
    }


def compute_section_three_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the primary sedimentation tank."""
    q_mld = inputs["design_discharge_q"]
    Db_hrs = inputs["detention_time_db"]
    G = inputs["specific_gravity_g"]
    d_mm = inputs["particle_size_d"]
    mu_scaled = inputs["viscosity_mu"]   # user-supplied as ×10⁻³ NS/m²
    H = inputs["side_water_depth_h"]
    lb_ratio = inputs["lb_ratio"]

    # Q = q × 10³ / (24 × 60 × 60)  →  m³/s
    Q = (q_mld * 1_000.0) / (24.0 * 60.0 * 60.0)

    # Vs = γ_w × (G−1) × d² / (18 × μ)   (Stokes' law)
    # γ_w = 9810 N/m³, d in metres, μ = viscosity_mu × 10⁻³ N·s/m²
    d_m = d_mm / 1_000.0
    mu = mu_scaled * 1e-3
    Vs = 9810.0 * (G - 1.0) * d_m ** 2 / (18.0 * mu) if mu else 0.0  # m/s

    # V = Q × Db (hrs) × 3600
    V = Q * Db_hrs * 3600.0  # m³

    # SA = V / H
    SA = V / H if H else 0.0  # m²

    # Rectangular tank: B = √(SA / lb_ratio), L = lb_ratio × B
    B = math.sqrt(SA / lb_ratio) if lb_ratio else 0.0  # m
    L = lb_ratio * B  # m

    # Equivalent circular diameter: D = √(4 × SA / π)
    D = math.sqrt(4.0 * SA / math.pi)  # m

    return {
        "design_discharge_q": q_mld,
        "discharge_Q": Q,
        "specific_gravity_g": G,
        "particle_size_d": d_mm,
        "viscosity_mu": mu_scaled,
        "settling_velocity_vs": Vs,
        "detention_time_db": Db_hrs,
        "side_water_depth_h": H,
        "lb_ratio": lb_ratio,
        "volume_v": V,
        "surface_area_sa": SA,
        "breadth_b": B,
        "length_l": L,
        "diameter_d": D,
    }


def compute_section_four_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the activated sludge process aeration tank."""
    q_mld = inputs["design_discharge_q"]
    S0 = inputs["inlet_bod_s0"]
    S1 = inputs["outlet_bod_s1"]
    Xt = inputs["mlss_xt"]
    HRT = inputs["hrt"]
    H = inputs["depth_h"]
    lb_ratio = inputs["lb_ratio"]

    # Q in m³/day: 1 MLD = 1000 m³/day
    Q_m3_day = q_mld * 1_000.0

    # BOD Load = Q (m³/day) × S0 (mg/L) × 10⁻³  →  kg BOD/day
    bod_load = Q_m3_day * S0 * 1e-3

    # Aeration tank volume: V = (Q × HRT) / 24
    V = (Q_m3_day * HRT) / 24.0  # m³

    # Tank area: A = V / H
    A = V / H if H else 0.0  # m²

    # Breadth: B = √(A / LB_ratio)
    B = math.sqrt(A / lb_ratio) if lb_ratio else 0.0  # m

    # Length: L = LB_ratio × B
    L = lb_ratio * B  # m

    # F/M ratio: F/M = (Q × S0) / (V × Xt)   [dimensionless — units cancel]
    fm_ratio = (Q_m3_day * S0) / (V * Xt) if (V and Xt) else 0.0

    # BOD removal efficiency: η = (S0 – S1) / S0 × 100
    eta = (S0 - S1) / S0 * 100.0 if S0 else 0.0  # %

    return {
        "design_discharge_q": q_mld,
        "discharge_Q_m3_day": Q_m3_day,
        "inlet_bod_s0": S0,
        "outlet_bod_s1": S1,
        "mlss_xt": Xt,
        "hrt": HRT,
        "depth_h": H,
        "lb_ratio": lb_ratio,
        "bod_load": bod_load,
        "volume_v": V,
        "area_a": A,
        "breadth_b": B,
        "length_l": L,
        "fm_ratio": fm_ratio,
        "efficiency_eta": eta,
    }


def compute_section_five_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the secondary clarifier."""
    q_mld = inputs["design_discharge_q"]
    DT = inputs["detention_time_dt"]
    d = inputs["depth_d"]

    # Step 1: Q in m³/day then m³/hr
    Q_m3_day = q_mld * 1_000.0
    Q_hr = Q_m3_day / 24.0

    # Step 2: Volume V = Q_hr × DT
    V = Q_hr * DT  # m³

    # Step 3: Surface area A = V / d
    A = V / d if d else 0.0  # m²

    # Step 4: Diameter D = √(4A / π)
    D = math.sqrt(4.0 * A / math.pi) if A > 0 else 0.0  # m

    # Step 5: Surface Overflow Rate SOR = Q_m3_day / A
    SOR = Q_m3_day / A if A else 0.0  # m³/m²/day

    sor_ok = 20.0 <= SOR <= 40.0

    return {
        "design_discharge_q": q_mld,
        "discharge_Q_m3_day": Q_m3_day,
        "discharge_Q_hr": Q_hr,
        "detention_time_dt": DT,
        "depth_d": d,
        "volume_v": V,
        "surface_area_a": A,
        "diameter_d": D,
        "sor": SOR,
        "sor_ok": sor_ok,
    }


def compute_section_six_metrics(inputs: Dict[str, float]) -> Dict[str, float]:
    """Compute design outputs for the oxidation pond."""
    q_mld          = inputs["design_discharge_q"]
    Li             = inputs["influent_bod_li"]
    Le             = inputs["effluent_bod_le"]
    T              = inputs["temperature_t"]
    K20            = inputs["k20"]
    d              = inputs["depth_d"]
    lb_ratio       = inputs["lb_ratio"]
    max_pond_ha    = inputs["max_pond_area_ha"]

    # Q in m³/day
    Q_m3_day = q_mld * 1_000.0

    # Step 1: Temperature-corrected rate constant  KT = K20 × 1.05^(T-20)
    KT = K20 * (1.05 ** (T - 20.0))

    # Step 2: Detention time  t = (Li/Le − 1) / KT  (days)
    t = (Li / Le - 1.0) / KT if (KT and Le) else 0.0

    # Step 3: Volume  V = Q × t
    V = Q_m3_day * t  # m³

    # Step 4: Surface area  A = V / d
    A = V / d if d else 0.0  # m²

    # Step 5: L:B dimensions  B = √(A/lb), L = lb × B
    B = math.sqrt(A / lb_ratio) if lb_ratio else 0.0
    L = lb_ratio * B

    # Step 6: Area in hectares
    A_ha = A / 10_000.0

    # Step 7: Number of ponds  N = round(A_ha / max_pond_ha), min 1
    N = max(1, round(A_ha / max_pond_ha)) if max_pond_ha else 1

    # Step 8: Per-pond breakdown
    A_each     = A / N
    Q_per_pond = Q_m3_day / N

    return {
        "design_discharge_q":  q_mld,
        "discharge_Q_m3_day":  Q_m3_day,
        "influent_bod_li":     Li,
        "effluent_bod_le":     Le,
        "temperature_t":       T,
        "k20":                 K20,
        "kt":                  KT,
        "depth_d":             d,
        "lb_ratio":            lb_ratio,
        "detention_time_t":    t,
        "volume_v":            V,
        "surface_area_a":      A,
        "surface_area_ha":     A_ha,
        "breadth_b":           B,
        "length_l":            L,
        "num_ponds_n":         N,
        "area_each_pond":      A_each,
        "q_per_pond":          Q_per_pond,
    }


def compute_section_metrics(section_id: str, inputs: Dict[str, float]) -> Dict[str, float]:
    """Delegate section-specific metric calculations."""
    if section_id == "section-1":
        return compute_section_one_metrics(inputs)
    if section_id == "section-2":
        return compute_section_two_metrics(inputs)
    if section_id == "section-3":
        return compute_section_three_metrics(inputs)
    if section_id == "section-4":
        return compute_section_four_metrics(inputs)
    if section_id == "section-5":
        return compute_section_five_metrics(inputs)
    if section_id == "section-6":
        return compute_section_six_metrics(inputs)
    # Future sections will define their own calculations.
    return {}


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("index"))

    errors: List[str] = []

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm_password", "")

        if not username:
            errors.append("Username is required.")
        elif len(username) < 3:
            errors.append("Username must be at least 3 characters.")

        if not password:
            errors.append("Password is required.")
        elif len(password) < 6:
            errors.append("Password must be at least 6 characters.")

        if password and confirm != password:
            errors.append("Passwords do not match.")

        if not errors:
            conn = get_db()
            existing = conn.execute(
                "SELECT id FROM users WHERE username = ?", (username,)
            ).fetchone()
            if existing:
                errors.append("Username already taken. Please choose another.")
            else:
                conn.execute(
                    "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
                    (username, generate_password_hash(password),
                     datetime.utcnow().isoformat(timespec="seconds")),
                )
                conn.commit()
                return redirect(url_for("login", registered="1"))

    return render_template("login.html", mode="register", errors=errors)


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("index"))

    errors: List[str] = []
    registered = request.args.get("registered") == "1"

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username:
            errors.append("Username is required.")
        if not password:
            errors.append("Password is required.")

        if not errors:
            conn = get_db()
            user = conn.execute(
                "SELECT id, password_hash FROM users WHERE username = ?", (username,)
            ).fetchone()
            if user is None or not check_password_hash(user["password_hash"], password):
                errors.append("Invalid username or password.")
            else:
                session.clear()
                session["user_id"] = user["id"]
                session["username"] = username
                return redirect(url_for("index"))

    return render_template("login.html", mode="login", errors=errors,
                           registered=registered)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/", methods=["GET", "POST"])
@login_required
def index():
    errors: Dict[str, List[str]] = {section["id"]: [] for section in SECTIONS}
    form_state: Dict[str, Dict[str, str]] = {section["id"]: {} for section in SECTIONS}

    if request.method == "POST":
        section_id = request.form.get("section_id", "")
        section_config = next((s for s in SECTIONS if s["id"] == section_id), None)

        if not section_config:
            errors.setdefault(section_id, []).append("Unknown section submitted.")
        else:
            section_fields_raw = section_config.get("fields")
            if not section_fields_raw:
                errors[section_id].append("This section is not yet interactive.")
            else:
                parsed_inputs: Dict[str, float] = {}
                section_fields = cast(List[Dict[str, object]], section_fields_raw)
                has_error = False

                for field in section_fields:
                    field_name = str(field["name"])
                    raw_value = request.form.get(field_name, "").strip()
                    form_state[section_id][field_name] = raw_value
                    required = field.get("required", True)
                    cast_type = field.get("cast", "float")

                    if not raw_value:
                        if required:
                            errors[section_id].append(f"{field['label']} is required.")
                            has_error = True
                        else:
                            parsed_inputs[field_name] = "" if cast_type == "str" else None
                        continue

                    try:
                        if cast_type == "int":
                            value = int(raw_value)
                        elif cast_type == "float":
                            value = float(raw_value)
                        elif cast_type == "str":
                            value = raw_value
                        else:
                            value = float(raw_value)
                    except ValueError:
                        errors[section_id].append(
                            f"{field['label']} must be a valid number."
                        )
                        has_error = True
                        continue

                    if cast_type in {"int", "float"}:
                        min_value = field.get("min_value")
                        if min_value is not None and value < min_value:
                            errors[section_id].append(
                                f"{field['label']} must be at least {min_value}."
                            )
                            has_error = True
                            continue

                    parsed_inputs[field_name] = value

                if not has_error:
                    metrics = compute_section_metrics(section_id, parsed_inputs)
                    persist_section_result(section_id, parsed_inputs, metrics)
                    return redirect(url_for("index", _anchor=section_id))

    if request.method == "POST":
        # Leave other sections with defaults if they were not part of the submission.
        pass

    latest_results = fetch_latest_section_results()

    for section in SECTIONS:
        section_id = section["id"]
        if form_state[section_id]:
            continue
        if section_id in latest_results:
            stored_inputs = latest_results[section_id]["inputs"]
            form_state[section_id] = {
                field_name: "" if value is None else str(value)
                for field_name, value in stored_inputs.items()
            }

    # Provide user-friendly defaults for module 1 optional descriptors
    if "section-1" in form_state:
        form_state["section-1"].setdefault("screen_type", "Medium Bar Screen")

    module1_diagram_rel = "images/bar_screen.jpg"
    module2_diagram_rel = "images/2.jpg"
    module3_diagram_rel = "images/3.jpg"
    module4_diagram_rel = "images/4.jpg"
    module5_diagram_rel = "images/5.jpg"
    context = {
        "sections": SECTIONS,
        "errors": errors,
        "form_state": form_state,
        "results": latest_results,
        "module1_diagram_path": module1_diagram_rel,
        "module1_diagram_exists": (BASE_DIR / "static" / module1_diagram_rel).exists(),
        "module2_diagram_path": module2_diagram_rel,
        "module2_diagram_exists": (BASE_DIR / "static" / module2_diagram_rel).exists(),
        "module3_diagram_path": module3_diagram_rel,
        "module3_diagram_exists": (BASE_DIR / "static" / module3_diagram_rel).exists(),
        "module4_diagram_path": module4_diagram_rel,
        "module4_diagram_exists": (BASE_DIR / "static" / module4_diagram_rel).exists(),
        "module5_diagram_path": module5_diagram_rel,
        "module5_diagram_exists": (BASE_DIR / "static" / module5_diagram_rel).exists(),
        "module6_diagram_path": "images/6.jpg",
        "module6_diagram_exists": (BASE_DIR / "static" / "images/6.jpg").exists(),
    }
    return render_template("index.html", **context)


with app.app_context():
    init_db()


if __name__ == "__main__":
    app.run(debug=True)
